import React, { useState, useEffect } from "react";

import api from "../api"; // importando a instância do Axios de "api.js"
import Navbar from "../components/Navbar";

import imagemLogo from "../assets/imagens/logo-verde.png";
import imagemAvatar from "../assets/imagens/avatar.png";
import CardMusica from "../components/CardMusica";

function Musicas() {

    const [musicas, setMusicas] = useState( [] ); // criando estado de vetor para uma lista de músicas  

    const [estadoParaObservar, setEstadoParaObservar] = useState("");

    useEffect(() => {listar()}, []);

    function listar() {
        console.log("Requisição está sendo feita: ");

        api.get()                               // invocando o método "get" do axios utilizando a URL base instanciada em "api.js"
        .then(function (respostaObtida) {       // método get responde uma Promise que será resolvida, e quando obtiver uma resposta, cairá no "then" recebendo a resposta como parâmetro
            console.log(respostaObtida.data);   // exibindo o atributo "data", que possui o vetor de dados do objeto de resposta que foi recebido
            setMusicas(respostaObtida.data);    // utilizando o setter para alterar o valor do estado (useState) de "musicas"        
        })
        .catch((errorOcorrido) => {             // caso a requisição falhe, o "catch" pegará o erro, recebendo como parâmetro de uma função
            console.log(errorOcorrido)          // exibindo o erro que ocorreu na requisição
        });
    }


    return (
        <React.Fragment>
            <Navbar />
            <div className="container">
                <div className="filter">
                    <button onClick={listar} className="btn">Adicionar</button>
                </div>
            </div>

            <div className="container">
                <div className="music-boxes">
                    <CardMusica year="1902" genre="dgf" artist="J" title="KKK"/>
                    {/* <CardMusica musica={{title: "asdfsd", artist: "asdf", genre: "sdf", year:"123"}}/> */}
                    <CardMusica year="1602" genre="tiu" artist="b" title="Receba"/>

                    {
                        musicas.map((musica, index) => {
                            return (
                                <CardMusica 
                                    key={index} 
                                    title={musica.title}
                                    artist={musica.artist}
                                    genre={musica.genre}
                                    year={musica.year}
                                />
                            )
                        })
                    }
                </div>
            </div>
        </React.Fragment>
    );
}

export default Musicas;