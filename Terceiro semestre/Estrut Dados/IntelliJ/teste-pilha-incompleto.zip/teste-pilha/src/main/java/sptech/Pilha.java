package sptech;

public class Pilha {

    // 01) Atributos
    private int[] pilha;
    private int topo;

    // 02) Construtor
    public Pilha(int capacidade) {

    }

    // 03) Método isEmpty
    public Boolean isEmpty() {
        return null;
    }

    // 04) Método isFull
    public Boolean isFull() {
        return null;
    }

    // 05) Método push
    public void push(int info) {

    }

    // 06) Método pop
    public int pop() {
        return 0;
    }

    // 07) Método peek
    public int peek() {
        return 0;
    }

    // 08) Método exibe
    public void exibe() {

    }


    //Getters & Setters (manter)
    public int getTopo() {
        return topo;
    }
}