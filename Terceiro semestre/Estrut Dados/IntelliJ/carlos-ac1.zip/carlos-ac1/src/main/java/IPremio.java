public interface IPremio {

    public double getPremio();

}
