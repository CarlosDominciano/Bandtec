public interface Bonavel {

    public Double getValorBonus(int horas, double valor);

}
