package sptech.projetojpadtoquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoJpaDtoQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
